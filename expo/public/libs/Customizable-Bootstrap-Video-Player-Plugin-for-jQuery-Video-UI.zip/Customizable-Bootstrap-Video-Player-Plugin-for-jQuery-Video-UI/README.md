Bootstrap video player jQuery-plugin
====================================

* A customizable HTML5 video player plugin for jQuery based on bootstrap UI , live demo & doc available on http://html5-ninja.com/item/Bootstrap-video-player-jQuery-plugin/5
* Don't Forget to Share http://html5-ninja.com :)
